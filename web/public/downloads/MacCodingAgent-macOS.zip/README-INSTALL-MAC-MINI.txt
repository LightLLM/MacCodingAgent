Mac Coding Agent — macOS latest (Mac Mini)
==========================================

Requirements
- macOS 13 Ventura or later (Sonoma / Sequoia supported)
- Apple Silicon Mac Mini (M1/M2/M3/M4) or Intel Mac Mini
- Internet once (first launch downloads Electron ~90MB)

Install
1. Unzip MacCodingAgent-macOS-latest.zip
2. Double-click "Install Mac Coding Agent.command"
3. If Gatekeeper warns: right-click → Open → Open
4. Wait for first-run runtime download, then the desktop app opens

Manual
- Drag "Mac Coding Agent.app" to /Applications
- Right-click → Open the first time

What you get
- Native desktop window on your Mac Mini
- Embedded local coding agent on localhost
- Offline stub model; optional Ollama for open-source models

Version: 1.0.0
