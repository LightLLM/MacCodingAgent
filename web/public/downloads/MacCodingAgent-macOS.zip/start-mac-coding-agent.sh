#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/Mac Coding Agent.app" 2>/dev/null || bash "$DIR/Mac Coding Agent.app/Contents/MacOS/MacCodingAgent"
