#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
xattr -dr com.apple.quarantine "Mac Coding Agent.app" 2>/dev/null || true
open "Mac Coding Agent.app"
