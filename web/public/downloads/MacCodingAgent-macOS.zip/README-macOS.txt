# Mac Coding Agent for macOS

1. Keep this folder next to the cloned MacCodingAgent repo **or** install dependencies inside Resources.
2. Double-click `Mac Coding Agent.app` (right-click → Open the first time if Gatekeeper warns).
3. Or run: `./start-mac-coding-agent.sh`
4. Buy Pro on the Pricing page (Stripe) to unlock updates / keep your license.

The desktop shell boots the local agent (:8787) + web dashboard (:3000) when Node/npm are available.
