#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
APP="Mac Coding Agent.app"
DEST="/Applications/Mac Coding Agent.app"

echo "========================================"
echo " Mac Coding Agent — Mac Mini installer"
echo "========================================"
echo
echo "Installing to /Applications…"
rm -rf "$DEST"
cp -R "$APP" "$DEST"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
chmod +x "$DEST/Contents/MacOS/MacCodingAgent"

echo
echo "Installed."
echo "First launch downloads the Electron runtime for your chip (Apple Silicon or Intel)."
echo "Opening Mac Coding Agent…"
open "$DEST"
